import{c as o}from"./createLucideIcon-C4-ri8sC.js";import{c as t}from"./utils-BMxewDCE.js";import{d as n,c as l,x as i,u as c,o as u}from"./app-0q7rNlax.js";/**
 * @license lucide-vue-next v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=o("ArrowRightIcon",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);/**
 * @license lucide-vue-next v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=o("CircleXIcon",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]]);/**
 * @license lucide-vue-next v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=o("MinusIcon",[["path",{d:"M5 12h14",key:"1ays0h"}]]),d=["value"],y=n({__name:"Textarea",props:{modelValue:{},class:{}},emits:["update:modelValue"],setup(s){return(e,r)=>(u(),l("textarea",i({class:c(t)("flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",e.$props.class)},e.$attrs,{value:s.modelValue,onInput:r[0]||(r[0]=a=>e.$emit("update:modelValue",a.target.value))}),null,16,d))}});export{g as A,h as C,b as M,y as _};
